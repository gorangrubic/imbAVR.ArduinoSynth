/*
  ==============================================================================

    imbSynthModelExporter.h
    Created: 8 Oct 2019 3:45:42am
    Author:  gorangrubic

  ==============================================================================
*/

#pragma once
class imbSynthModelExporter {
 
    public:
    
    imbSynthModelExporter();
};