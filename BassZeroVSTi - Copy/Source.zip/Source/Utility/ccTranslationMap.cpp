#include "ccTranslationMap.h"



ccTranslationMap::ccTranslationMap()
{
}


ccTranslationMap::~ccTranslationMap()
{
}
