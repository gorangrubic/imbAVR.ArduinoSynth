#pragma once
#include "../JuceLibraryCode/JuceHeader.h"
class imbSynthPresetDefinition
{
public:
	imbSynthPresetDefinition();
	~imbSynthPresetDefinition();
};

