#include "imbSynthStateUtilityData.h"



imbSynthStateUtilityData::imbSynthStateUtilityData()
{
}


imbSynthStateUtilityData::~imbSynthStateUtilityData()
{
}
