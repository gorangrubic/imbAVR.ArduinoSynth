#pragma once

#include "../JuceLibraryCode/JuceHeader.h"
//#include "juce_audio_processors\utilities\juce_AudioParameterInt.h"
//#include "juce_audio_processors\processors\juce_AudioProcessorParameterGroup.h";
#include "imbControlParameter.h"
#include "imbSynthAudioProcessor.h"

//class imbParameterGroupBase
//{
//public:
//
//	String GroupName;
//	String GroupLabel;
//	
//	juce::AudioProcessorParameterGroup CP_Group;
//
//	
//
//	imbSynthAudioProcessor * ParentProcessor;
//	
//	imbControlParameter AddParameter(String _parameterID, String _parameterLabel, int MinValue, int MaxValue, int InitValue, String _parameterUnit);
//
//	imbParameterGroupBase(imbSynthAudioProcessor * _ParentProcessor, String _groupName, String _groupLabel);
//	~imbParameterGroupBase();
//};

