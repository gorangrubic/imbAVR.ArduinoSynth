/*
  ==============================================================================

    ModelComponentDescription.cpp
    Created: 8 Oct 2019 5:36:31am
    Author:  gorangrubic

  ==============================================================================
*/

#include "ModelComponentDescription.h"

ModelComponentDescription::ModelComponentDescription()
  {
  }
