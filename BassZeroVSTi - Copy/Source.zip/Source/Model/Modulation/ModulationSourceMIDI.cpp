/*
  ==============================================================================

    ModulationSourceMIDI.cpp
    Created: 4 Oct 2019 10:00:31pm
    Author:  gorangrubic

  ==============================================================================
*/

#include "ModulationSourceMIDI.h"

void ModulationSourceMIDI::Deploy()
  {
  }

  ModulationSourceMIDI::ModulationSourceMIDI() {
	type = ModulationSourceType::MIDI;

}

//ModulationSourceMIDI::ModulationSourceMIDI(SynthDeviceModel * _root, SynthDeviceModelComponentBase * _parent, String _shortName, String _longName) :ModulationSourceBase(_root, _parent, _shortName, _longName) {
//	type = ModulationSourceType::MIDI;
//
//}