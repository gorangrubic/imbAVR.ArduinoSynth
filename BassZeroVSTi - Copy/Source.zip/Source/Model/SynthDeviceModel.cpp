/*
  ==============================================================================

    SynthDeviceModel.cpp
    Created: 1 Oct 2019 10:58:41am
    Author:  gorangrubic

  ==============================================================================
*/

#include "SynthDeviceModel.h"

void SynthDeviceModel::PreDeployModel()
  {
  }

  void SynthDeviceModel::AfterDeployModel()
  {


	
  }

  void SynthDeviceModel::Deploy()
  {
  }

  SynthDeviceModel::SynthDeviceModel()
  {
  }
