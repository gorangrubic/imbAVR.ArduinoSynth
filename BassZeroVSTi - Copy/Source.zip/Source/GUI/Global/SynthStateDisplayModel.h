/*
  ==============================================================================

    SynthStateDisplayModel.h
    Created: 4 Oct 2019 5:31:18pm
    Author:  gorangrubic

  ==============================================================================
*/

#pragma once
#include "../JuceLibraryCode/JuceHeader.h"

class SynthStateDisplayModel {

public:

	SynthStateDisplayModel();
};
