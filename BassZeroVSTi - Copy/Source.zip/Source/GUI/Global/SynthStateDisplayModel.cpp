/*
  ==============================================================================

    SynthStateDisplayModel.cpp
    Created: 4 Oct 2019 5:31:18pm
    Author:  gorangrubic

  ==============================================================================
*/

#include "SynthStateDisplayModel.h"



SynthStateDisplayModel::SynthStateDisplayModel()
{
}
