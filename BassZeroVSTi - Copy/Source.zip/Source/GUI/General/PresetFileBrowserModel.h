/*
  ==============================================================================

    PresetFileBrowserModel.h
    Created: 1 Oct 2019 1:38:09am
    Author:  gorangrubic

  ==============================================================================
*/

#pragma once
#include "../JuceLibraryCode/JuceHeader.h"
class PresetFileBrowserModel {
    
 public:
 
 
	 PresetFileBrowserModel();
 
};