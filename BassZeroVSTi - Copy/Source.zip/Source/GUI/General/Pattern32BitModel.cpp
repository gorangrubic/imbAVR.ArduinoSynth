/*
  ==============================================================================

    Pattern32BitModel.cpp
    Created: 1 Oct 2019 1:57:25am
    Author:  gorangrubic

  ==============================================================================
*/

#include "Pattern32BitModel.h"


  Pattern32BitModel::Pattern32BitModel()
  {
  }
