/*
  ==============================================================================

    ControlStateDisplayModel.h
    Created: 3 Oct 2019 5:19:29am
    Author:  gorangrubic

  ==============================================================================
*/

#pragma once
#include "../JuceLibraryCode/JuceHeader.h"

class ControlStateDisplayModel {

public:

	ControlStateDisplayModel();
};