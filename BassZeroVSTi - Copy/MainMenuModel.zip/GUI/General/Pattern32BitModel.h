/*
  ==============================================================================

    Pattern32BitModel.h
    Created: 1 Oct 2019 1:57:25am
    Author:  gorangrubic

  ==============================================================================
*/

#pragma once
#include "../JuceLibraryCode/JuceHeader.h"

class Pattern32BitModel {
 
    public:
    
    char block1;
    char block2;
    char block3;
    char block4;
  
	Pattern32BitModel();
};