/*
  ==============================================================================

    PathBrowserModel.h
    Created: 1 Oct 2019 1:08:41am
    Author:  gorangrubic

  ==============================================================================
*/

#pragma once
#include "../JuceLibraryCode/JuceHeader.h"

class PathBrowserModel {
 
    public:
    
        String Title;
        String CurrentPath;
       
    
    PathBrowserModel();
};