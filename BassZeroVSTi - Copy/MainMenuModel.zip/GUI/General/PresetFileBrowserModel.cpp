/*
  ==============================================================================

    PresetFileBrowserModel.cpp
    Created: 1 Oct 2019 1:38:09am
    Author:  gorangrubic

  ==============================================================================
*/

#include "PresetFileBrowserModel.h"


  PresetFileBrowserModel::PresetFileBrowserModel()
  {
  }
