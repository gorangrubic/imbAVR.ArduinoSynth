/*
  ==============================================================================

    ModulationSourceBase.cpp
    Created: 4 Oct 2019 10:00:17pm
    Author:  gorangrubic

  ==============================================================================
*/

#include "ModulationSourceBase.h"

ModulationSourceBase::ModulationSourceBase()
{
}
