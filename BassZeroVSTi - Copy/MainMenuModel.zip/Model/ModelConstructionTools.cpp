/*
  ==============================================================================

    ModelConstructionTools.cpp
    Created: 8 Oct 2019 6:04:33am
    Author:  gorangrubic

  ==============================================================================
*/

#include "ModelConstructionTools.h"

void ModelConstructionTools::Connect(imbControlParameter parameter, SynthDeviceModelComponentBase * _parent)
  {


		//Parent = _parent;


		//parameterIDPath = _parent->ShortName + "_" + parameterID;

		//AudioProcessorValueTreeState& valueTreeState = _parent->Root->SynthProcessor->parameters;

		//std::function<String(float)> valueToTextFunction = imbSynthTools::floatToText<imbControlParameterType::Boolean>;
		//std::function<float(const String&)> textToValueFunction = imbSynthTools::textToFloat<imbControlParameterType::Boolean>;

		//switch (typeParameter) {
		//case imbControlParameterType::Float:
		//	valueToTextFunction = imbSynthTools::floatToText<imbControlParameterType::Float>;
		//	textToValueFunction = imbSynthTools::textToFloat<imbControlParameterType::Float>;
		//	break;
		//case imbControlParameterType::Ratio:
		//	valueToTextFunction = imbSynthTools::floatToText<imbControlParameterType::Ratio>;
		//	textToValueFunction = imbSynthTools::textToFloat<imbControlParameterType::Ratio>;
		//	break;
		//case imbControlParameterType::Enumeration:
		//	valueToTextFunction = imbSynthTools::floatToText<imbControlParameterType::Enumeration>;
		//	textToValueFunction = imbSynthTools::textToFloat<imbControlParameterType::Enumeration>;
		//	break;
		//case imbControlParameterType::Integer:
		//	valueToTextFunction = imbSynthTools::floatToText<imbControlParameterType::Integer>;
		//	textToValueFunction = imbSynthTools::textToFloat<imbControlParameterType::Integer>;
		//	break;
		//case imbControlParameterType::Boolean:
		//	valueToTextFunction = imbSynthTools::floatToText<imbControlParameterType::Boolean>;
		//	textToValueFunction = imbSynthTools::textToFloat<imbControlParameterType::Boolean>;
		//	break;
		//}

		//parameter = valueTreeState.createAndAddParameter(parameterIDPath, parameterID, parameterLabel,
		//	NormalisableRange<float>(MinValue, MaxValue, IntervalValue),
		//	imbSynthTools::ProcessValue(Value, typeParameter),
		//	valueToTextFunction,
		//	textToValueFunction,
		//	false,
		//	isAutomatizable,
		//	isDescreteValue,
		//	category,
		//	typeParameter == imbControlParameterType::Boolean
		//);


		//valueTreeState.addParameterListener(parameterIDPath, &Listener);

	

  }
