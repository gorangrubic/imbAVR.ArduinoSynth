/*
  ==============================================================================

    OscilatorBase.cpp
    Created: 4 Oct 2019 10:05:21pm
    Author:  gorangrubic

  ==============================================================================
*/

#include "OscilatorBase.h"

OscilatorBase::OscilatorBase()
  {
  }
