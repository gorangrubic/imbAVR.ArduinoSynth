#pragma once
class ccTranslationMap
{
public:
	ccTranslationMap();
	~ccTranslationMap();
};

