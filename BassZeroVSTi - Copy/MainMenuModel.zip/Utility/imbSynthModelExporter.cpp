/*
  ==============================================================================

    imbSynthModelExporter.cpp
    Created: 8 Oct 2019 3:45:42am
    Author:  gorangrubic

  ==============================================================================
*/

#include "imbSynthModelExporter.h"

imbSynthModelExporter::imbSynthModelExporter()
{
}
