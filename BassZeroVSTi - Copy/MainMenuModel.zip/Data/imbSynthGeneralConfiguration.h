#pragma once
#include "../JuceLibraryCode/JuceHeader.h"
class imbSynthGeneralConfiguration
{
public:
	imbSynthGeneralConfiguration();
	~imbSynthGeneralConfiguration();
};

