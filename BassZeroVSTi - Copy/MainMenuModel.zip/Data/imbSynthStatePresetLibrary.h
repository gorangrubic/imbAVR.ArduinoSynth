#pragma once
#include "../JuceLibraryCode/JuceHeader.h"
class imbSynthStatePresetLibrary
{
public:
	imbSynthStatePresetLibrary();
	~imbSynthStatePresetLibrary();
};

