#include "imbSynthStateData.h"



imbSynthStateData::imbSynthStateData()
{
}


imbSynthStateData::~imbSynthStateData()
{
}
