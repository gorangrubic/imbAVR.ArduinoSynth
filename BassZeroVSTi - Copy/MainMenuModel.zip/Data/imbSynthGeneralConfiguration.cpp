#include "imbSynthGeneralConfiguration.h"



imbSynthGeneralConfiguration::imbSynthGeneralConfiguration()
{
}


imbSynthGeneralConfiguration::~imbSynthGeneralConfiguration()
{
}
