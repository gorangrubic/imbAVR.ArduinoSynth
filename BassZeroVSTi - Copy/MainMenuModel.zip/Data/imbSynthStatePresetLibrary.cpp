#include "imbSynthStatePresetLibrary.h"



imbSynthStatePresetLibrary::imbSynthStatePresetLibrary()
{
}


imbSynthStatePresetLibrary::~imbSynthStatePresetLibrary()
{
}
