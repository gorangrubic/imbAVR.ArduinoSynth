#include "imbSynthPresetDefinition.h"



imbSynthPresetDefinition::imbSynthPresetDefinition()
{
}


imbSynthPresetDefinition::~imbSynthPresetDefinition()
{
}
